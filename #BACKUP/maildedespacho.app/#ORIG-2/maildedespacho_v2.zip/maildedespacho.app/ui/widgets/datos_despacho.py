# coding: utf-8
"""
ui/widgets/datos_despacho.py — Formulario de datos del despacho.

CORRECCIONES respecto a la versión anterior:
  - data_changed() era llamado con argumentos (textEdited pasa str, pero
    la señal no acepta argumentos). Solución: lambda sin arg → emit()
  - currentIndexChanged pasa int; usar lambda _ : self.data_changed.emit()
  - blockSignals() durante hard/soft reset para evitar cascadas
"""

from __future__ import annotations
import logging
from PySide6.QtCore import Signal, QSize, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QComboBox, QPushButton, QFrame,
)
from svgs import SVG, apply_svg_icon
from theme import QSSD
from config_loader import ConfigLoader

logger = logging.getLogger(__name__)

MAX_POL  = 12
MAX_END  = 5
MAX_DECL = 5

# ── helpers de layout ──────────────────────────────────────────────────────────

def _vfield(label_text: str, placeholder: str = "") -> tuple[QLabel, QLineEdit]:
    lbl = QLabel(label_text)
    lbl.setObjectName("FieldLabel")
    inp = QLineEdit()
    inp.setPlaceholderText(placeholder or label_text)
    return lbl, inp


def _vcombo(label_text: str, items: list[str]) -> tuple[QLabel, QComboBox]:
    lbl = QLabel(label_text)
    lbl.setObjectName("FieldLabel")
    cb = QComboBox()
    cb.addItem("")
    cb.addItems(items)
    return lbl, cb


def _wrap_vfield(lbl: QLabel, widget: QWidget) -> QWidget:
    """Envuelve label + widget en un QWidget con QVBoxLayout."""
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(4)
    lay.addWidget(lbl)
    lay.addWidget(widget)
    return w


class DatosDespacho(QWidget):
    data_changed    = Signal()   # sin argumentos — compatible con todos los slots
    paste_requested = Signal()

    def __init__(self, cfg: ConfigLoader, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._cfg = cfg
        self._pol_rows:  list[dict] = []
        self._end_rows:  list[dict] = []
        self._decl_rows: list[dict] = []
        self._asunto_usr_edited = False
        self._build()

    # ── Construcción ──────────────────────────────────────────────────────────

    def _build(self):
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(QSSD["spacing_datos_fields"])

        # ── Fila 1: Contratante + Contacto ───────────────────────────────────
        row1 = QHBoxLayout()
        row1.setSpacing(QSSD["spacing_field_inline"])
        lbl_c, self._inp_contratante = _vfield("Nombre contratante / asegurado", "Nombre o razón social")
        lbl_ct, self._inp_contacto   = _vfield("Persona de contacto", "Contacto directo")
        row1.addWidget(_wrap_vfield(lbl_c, self._inp_contratante))
        row1.addWidget(_wrap_vfield(lbl_ct, self._inp_contacto))
        self._lay.addLayout(row1)

        # ── Fila 2: CIA + Vigencia desde + Vigencia hasta ─────────────────────
        self._row2 = QHBoxLayout()
        self._row2.setSpacing(QSSD["spacing_field_inline"])

        lbl_cia, self._cb_cia = _vcombo("CIA aseguradora", self._cfg.aseguradoras())
        self._row2.addWidget(_wrap_vfield(lbl_cia, self._cb_cia))

        lbl_vi, self._inp_vig_ini = _vfield("Vigencia desde", "2024")
        self._inp_vig_ini.setMaxLength(4)
        self._w_vig_ini = _wrap_vfield(lbl_vi, self._inp_vig_ini)
        self._row2.addWidget(self._w_vig_ini)

        lbl_vf, self._inp_vig_fin = _vfield("Vigencia hasta", "2025")
        self._inp_vig_fin.setMaxLength(4)
        self._w_vig_fin = _wrap_vfield(lbl_vf, self._inp_vig_fin)
        self._row2.addWidget(self._w_vig_fin)

        lbl_mes, self._inp_mes = _vfield("Mes de declaración", "Ej. Marzo 2025")
        self._w_mes = _wrap_vfield(lbl_mes, self._inp_mes)
        self._w_mes.hide()
        self._row2.addWidget(self._w_mes)

        self._lay.addLayout(self._row2)

        # ── Sección pólizas ───────────────────────────────────────────────────
        self._sec_pol = QWidget()
        self._sec_pol_lay = QVBoxLayout(self._sec_pol)
        self._sec_pol_lay.setContentsMargins(0, 0, 0, 0)
        self._sec_pol_lay.setSpacing(6)
        self._sec_pol.hide()
        self._lay.addWidget(self._sec_pol)

        self._btn_add_pol = self._make_add_btn("Agregar póliza", self._on_add_pol)
        self._btn_add_pol.hide()
        self._lay.addWidget(self._btn_add_pol)

        # ── Sección endosos ───────────────────────────────────────────────────
        self._sec_end = QWidget()
        self._sec_end_lay = QVBoxLayout(self._sec_end)
        self._sec_end_lay.setContentsMargins(0, 0, 0, 0)
        self._sec_end_lay.setSpacing(6)
        self._sec_end.hide()
        self._lay.addWidget(self._sec_end)

        self._btn_add_end = self._make_add_btn("Agregar endoso", self._on_add_end)
        self._btn_add_end.hide()
        self._lay.addWidget(self._btn_add_end)

        # ── Sección declaraciones ─────────────────────────────────────────────
        self._sec_decl = QWidget()
        self._sec_decl_lay = QVBoxLayout(self._sec_decl)
        self._sec_decl_lay.setContentsMargins(0, 0, 0, 0)
        self._sec_decl_lay.setSpacing(6)
        self._sec_decl.hide()
        self._lay.addWidget(self._sec_decl)

        self._btn_add_decl = self._make_add_btn("Agregar declaración", self._on_add_decl)
        self._btn_add_decl.hide()
        self._lay.addWidget(self._btn_add_decl)

        # ── Separador asunto ──────────────────────────────────────────────────
        self._sep_asunto = QFrame()
        self._sep_asunto.setFrameShape(QFrame.HLine)
        self._sep_asunto.setFixedHeight(1)
        self._sep_asunto.hide()
        self._lay.addWidget(self._sep_asunto)

        # ── Asunto editable ───────────────────────────────────────────────────
        self._asunto_wrap = QWidget()
        self._asunto_wrap.hide()
        aw = QVBoxLayout(self._asunto_wrap)
        aw.setContentsMargins(0, 0, 0, 0)
        aw.setSpacing(4)
        lbl_as = QLabel("Asunto del correo (editable)")
        lbl_as.setObjectName("FieldLabel")
        aw.addWidget(lbl_as)
        self._inp_asunto = QLineEdit()
        self._inp_asunto.setObjectName("AsuntoEdit")
        self._inp_asunto.setPlaceholderText("Se generará automáticamente...")
        aw.addWidget(self._inp_asunto)
        self._lbl_char = QLabel("0 caracteres")
        self._lbl_char.setStyleSheet(f"color: {QSSD['asunto_char_normal']}; font-size: 11px;")
        aw.addWidget(self._lbl_char)
        self._lay.addWidget(self._asunto_wrap)

        # ── Error paste ───────────────────────────────────────────────────────
        self._paste_error = QLabel("")
        self._paste_error.setObjectName("InlineError")
        self._paste_error.setWordWrap(True)
        self._paste_error.hide()
        self._lay.addWidget(self._paste_error)

        # ── Botón Pegar ───────────────────────────────────────────────────────
        self._btn_paste = QPushButton("  Pegar datos del portapapeles")
        self._btn_paste.setProperty("role", "btn-paste")
        apply_svg_icon(self._btn_paste, SVG.PEGAR, QSize(14, 14), QSSD["text_muted"])
        self._btn_paste.clicked.connect(self.paste_requested.emit)
        self._lay.addWidget(self._btn_paste)

        # ── Conectar señales de campos fijos ──────────────────────────────────
        # CORRECCIÓN: usar lambda sin argumentos. textEdited emite str,
        # currentIndexChanged emite int — ninguno compatible con Signal() sin args.
        self._inp_contratante.textEdited.connect(lambda _: self.data_changed.emit())
        self._inp_contacto.textEdited.connect(lambda _: self.data_changed.emit())
        self._inp_vig_ini.textEdited.connect(lambda _: self.data_changed.emit())
        self._inp_vig_fin.textEdited.connect(lambda _: self.data_changed.emit())
        self._inp_mes.textEdited.connect(lambda _: self.data_changed.emit())
        self._cb_cia.currentIndexChanged.connect(lambda _: self._on_cia_changed())
        self._inp_asunto.textEdited.connect(lambda _: self._on_asunto_edited())

    # ── Botones de fila ───────────────────────────────────────────────────────

    def _make_add_btn(self, label: str, slot) -> QPushButton:
        btn = QPushButton(f"  {label}")
        btn.setProperty("role", "btn-add-row")
        apply_svg_icon(btn, SVG.AGREGAR, QSize(14, 14), QSSD["btn_add_row_text"])
        btn.clicked.connect(slot)
        return btn

    def _make_del_btn(self) -> QPushButton:
        btn = QPushButton()
        btn.setProperty("role", "btn-del-row")
        btn.setToolTip("Eliminar fila")
        btn.setFixedSize(QSSD["btn_del_size"], QSSD["btn_del_size"])
        apply_svg_icon(btn, SVG.ELIMINAR, QSize(14, 14), QSSD["btn_del_icon"])
        return btn

    def _update_add_btn(self, btn: QPushButton, count: int, max_count: int,
                        base_label: str, visible: bool):
        btn.setVisible(visible)
        at_max = count >= max_count
        btn.setDisabled(at_max)
        btn.setText(f"  Máximo {max_count}" if at_max else f"  {base_label}")

    # ── Fila de póliza ────────────────────────────────────────────────────────

    def _make_pol_row(self, removable: bool,
                      ramo: str = "", pol: str = "") -> dict:
        row_w = QWidget()
        lay = QHBoxLayout(row_w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(QSSD["spacing_field_inline"])

        lbl_r, cb_r = _vcombo("Ramo", self._cfg.ramos())
        if ramo:
            idx = cb_r.findText(ramo)
            if idx >= 0: cb_r.setCurrentIndex(idx)
        lay.addWidget(_wrap_vfield(lbl_r, cb_r))

        lbl_p, inp_p = _vfield("Nro. de póliza", "001-2024-00123")
        if pol: inp_p.setText(pol)
        lay.addWidget(_wrap_vfield(lbl_p, inp_p))

        d: dict = {"ramo_cb": cb_r, "pol_inp": inp_p, "row_widget": row_w}

        if removable:
            del_btn = self._make_del_btn()
            del_btn.clicked.connect(lambda _, dd=d: self._remove_pol_row(dd))
            lay.addWidget(del_btn, 0, Qt.AlignBottom)
            d["del_btn"] = del_btn

        # CORRECCIÓN: lambda ignora el argumento emitido por la señal
        cb_r.currentIndexChanged.connect(lambda _: self.data_changed.emit())
        inp_p.textEdited.connect(lambda _: self.data_changed.emit())
        return d

    # ── Fila de endoso ────────────────────────────────────────────────────────

    def _make_end_row(self, removable: bool, label_endoso: str,
                      ramo: str = "", pol: str = "",
                      end: str = "", mov: str = "") -> dict:
        row_w = QWidget()
        lay = QHBoxLayout(row_w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(QSSD["spacing_field_inline"])

        lbl_r, cb_r = _vcombo("Ramo", self._cfg.ramos())
        if ramo:
            idx = cb_r.findText(ramo)
            if idx >= 0: cb_r.setCurrentIndex(idx)
        lay.addWidget(_wrap_vfield(lbl_r, cb_r))

        lbl_p, inp_p = _vfield("Nro. de póliza", "Nro.")
        if pol: inp_p.setText(pol)
        lay.addWidget(_wrap_vfield(lbl_p, inp_p))

        lbl_e, inp_e = _vfield(label_endoso, "END-001")
        if end: inp_e.setText(end)
        lay.addWidget(_wrap_vfield(lbl_e, inp_e))

        lbl_m, inp_m = _vfield("Movimiento del endoso", "Descripción...")
        if mov: inp_m.setText(mov)
        lay.addWidget(_wrap_vfield(lbl_m, inp_m))

        d: dict = {
            "ramo_cb": cb_r, "pol_inp": inp_p,
            "end_inp": inp_e, "mov_inp": inp_m,
            "lbl_end": lbl_e, "row_widget": row_w,
        }

        if removable:
            del_btn = self._make_del_btn()
            del_btn.clicked.connect(lambda _, dd=d: self._remove_end_row(dd))
            lay.addWidget(del_btn, 0, Qt.AlignBottom)
            d["del_btn"] = del_btn

        cb_r.currentIndexChanged.connect(lambda _: self.data_changed.emit())
        for inp in [inp_p, inp_e, inp_m]:
            inp.textEdited.connect(lambda _: self.data_changed.emit())
        return d

    # ── Fila de declaración ───────────────────────────────────────────────────

    def _make_decl_row(self, removable: bool,
                       nro: str = "", mes: str = "") -> dict:
        row_w = QWidget()
        lay = QHBoxLayout(row_w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(QSSD["spacing_field_inline"])

        lbl_n, inp_n = _vfield("Nro. de declaración", "DEC-001")
        if nro: inp_n.setText(nro)
        lay.addWidget(_wrap_vfield(lbl_n, inp_n))

        lbl_m, inp_m = _vfield("Mes de declaración", "Ej. Marzo 2025")
        if mes: inp_m.setText(mes)
        lay.addWidget(_wrap_vfield(lbl_m, inp_m))

        d: dict = {"nro_inp": inp_n, "mes_inp": inp_m, "row_widget": row_w}

        if removable:
            del_btn = self._make_del_btn()
            del_btn.clicked.connect(lambda _, dd=d: self._remove_decl_row(dd))
            lay.addWidget(del_btn, 0, Qt.AlignBottom)
            d["del_btn"] = del_btn

        inp_n.textEdited.connect(lambda _: self.data_changed.emit())
        inp_m.textEdited.connect(lambda _: self.data_changed.emit())
        return d

    # ── Eliminar filas ────────────────────────────────────────────────────────

    def _remove_pol_row(self, d: dict):
        if d in self._pol_rows:
            d["row_widget"].deleteLater()
            self._pol_rows.remove(d)
            self._update_add_btn(self._btn_add_pol, len(self._pol_rows),
                                 MAX_POL, "Agregar póliza", True)
            self.data_changed.emit()

    def _remove_end_row(self, d: dict):
        if d in self._end_rows:
            d["row_widget"].deleteLater()
            self._end_rows.remove(d)
            self._update_add_btn(self._btn_add_end, len(self._end_rows),
                                 MAX_END, "Agregar endoso", True)
            self.data_changed.emit()

    def _remove_decl_row(self, d: dict):
        if d in self._decl_rows:
            d["row_widget"].deleteLater()
            self._decl_rows.remove(d)
            self._update_add_btn(self._btn_add_decl, len(self._decl_rows),
                                 MAX_DECL, "Agregar declaración", True)
            self.data_changed.emit()

    # ── Agregar filas ─────────────────────────────────────────────────────────

    def _on_add_pol(self):
        if len(self._pol_rows) >= MAX_POL: return
        d = self._make_pol_row(removable=True)
        self._pol_rows.append(d)
        self._sec_pol_lay.addWidget(d["row_widget"])
        self._update_add_btn(self._btn_add_pol, len(self._pol_rows),
                             MAX_POL, "Agregar póliza", True)
        self.data_changed.emit()

    def _on_add_end(self):
        if len(self._end_rows) >= MAX_END: return
        lb = self._cfg.label_endoso(self._cb_cia.currentText())
        d = self._make_end_row(removable=True, label_endoso=lb)
        self._end_rows.append(d)
        self._sec_end_lay.addWidget(d["row_widget"])
        self._update_add_btn(self._btn_add_end, len(self._end_rows),
                             MAX_END, "Agregar endoso", True)
        self.data_changed.emit()

    def _on_add_decl(self):
        if len(self._decl_rows) >= MAX_DECL: return
        d = self._make_decl_row(removable=True)
        self._decl_rows.append(d)
        self._sec_decl_lay.addWidget(d["row_widget"])
        self._update_add_btn(self._btn_add_decl, len(self._decl_rows),
                             MAX_DECL, "Agregar declaración", True)
        self.data_changed.emit()

    def _on_cia_changed(self):
        cia = self._cb_cia.currentText()
        lb = self._cfg.label_endoso(cia)
        for row in self._end_rows:
            if "lbl_end" in row:
                row["lbl_end"].setText(lb)
        self.data_changed.emit()

    def _on_asunto_edited(self):
        self._asunto_usr_edited = True
        self._update_char_count()
        self.data_changed.emit()

    def _update_char_count(self):
        n = len(self._inp_asunto.text())
        self._lbl_char.setText(f"{n} caracteres")
        if n > 100:
            color = QSSD['asunto_char_over']
        elif n > 80:
            color = QSSD['asunto_char_warn']
        else:
            color = QSSD['asunto_char_normal']
        self._lbl_char.setStyleSheet(f"color: {color}; font-size: 11px;")

    # ── API pública ───────────────────────────────────────────────────────────

    def adapt_fields(self, tpl_l1: str, tpl_l2: str, cia: str):
        """Muestra/oculta secciones. Llama blockSignals para evitar cascadas."""
        es_pol  = tpl_l1 == "Póliza"
        es_end  = tpl_l1 == "Endoso"
        es_decl = tpl_l1 == "Declaración mensual"
        es_prog = "programa" in tpl_l2.lower()
        es_col  = "colectivo" in tpl_l2.lower()
        es_multi = es_prog or es_col

        # Vigencia
        show_anual = not es_decl
        self._w_vig_ini.setVisible(show_anual)
        self._w_vig_fin.setVisible(show_anual)
        self._w_mes.setVisible(es_decl)

        # Pólizas
        if es_pol:
            self._sec_pol.show()
            if not self._pol_rows:
                d = self._make_pol_row(removable=False)
                self._pol_rows.append(d)
                self._sec_pol_lay.addWidget(d["row_widget"])
            self._update_add_btn(self._btn_add_pol, len(self._pol_rows),
                                 MAX_POL, "Agregar póliza", es_multi)
        else:
            self._sec_pol.hide()
            self._btn_add_pol.hide()

        # Endosos
        if es_end:
            self._sec_end.show()
            lb = self._cfg.label_endoso(cia)
            if not self._end_rows:
                d = self._make_end_row(removable=False, label_endoso=lb)
                self._end_rows.append(d)
                self._sec_end_lay.addWidget(d["row_widget"])
            if self._end_rows and "lbl_end" in self._end_rows[0]:
                self._end_rows[0]["lbl_end"].setText(lb)
            self._update_add_btn(self._btn_add_end, len(self._end_rows),
                                 MAX_END, "Agregar endoso", es_col)
        else:
            self._sec_end.hide()
            self._btn_add_end.hide()

        # Declaraciones
        if es_decl:
            self._sec_decl.show()
            if not self._decl_rows:
                d = self._make_decl_row(removable=False)
                self._decl_rows.append(d)
                self._sec_decl_lay.addWidget(d["row_widget"])
            self._update_add_btn(self._btn_add_decl, len(self._decl_rows),
                                 MAX_DECL, "Agregar declaración", es_col)
        else:
            self._sec_decl.hide()
            self._btn_add_decl.hide()

    def hard_reset(self):
        """Reset total — bloquea señales durante limpieza."""
        for w in [self._inp_contratante, self._inp_contacto,
                  self._inp_vig_ini, self._inp_vig_fin,
                  self._inp_mes, self._inp_asunto]:
            w.blockSignals(True)
            w.clear()
            w.blockSignals(False)

        self._cb_cia.blockSignals(True)
        self._cb_cia.setCurrentIndex(0)
        self._cb_cia.blockSignals(False)

        for rows in [self._pol_rows, self._end_rows, self._decl_rows]:
            for d in rows:
                d["row_widget"].deleteLater()
            rows.clear()

        self._asunto_usr_edited = False
        self._update_char_count()
        self._paste_error.hide()

    def soft_reset_for_l1(self, new_l1: str):
        if new_l1 != "Póliza":
            for d in self._pol_rows: d["row_widget"].deleteLater()
            self._pol_rows.clear()
        if new_l1 != "Endoso":
            for d in self._end_rows: d["row_widget"].deleteLater()
            self._end_rows.clear()
        if new_l1 != "Declaración mensual":
            for d in self._decl_rows: d["row_widget"].deleteLater()
            self._decl_rows.clear()

    def soft_reset_for_l2(self, tpl_l1: str, prev_l2: str, new_l2: str):
        def _is_multi(l2): return "programa" in l2.lower() or "colectivo" in l2.lower()
        if not _is_multi(prev_l2) or _is_multi(new_l2):
            return
        if tpl_l1 == "Póliza" and len(self._pol_rows) > 1:
            for d in self._pol_rows[1:]: d["row_widget"].deleteLater()
            self._pol_rows = self._pol_rows[:1]
        elif tpl_l1 == "Endoso" and len(self._end_rows) > 1:
            for d in self._end_rows[1:]: d["row_widget"].deleteLater()
            self._end_rows = self._end_rows[:1]
        elif tpl_l1 == "Declaración mensual" and len(self._decl_rows) > 1:
            for d in self._decl_rows[1:]: d["row_widget"].deleteLater()
            self._decl_rows = self._decl_rows[:1]

    def set_asunto_visible(self, visible: bool):
        self._asunto_wrap.setVisible(visible)
        self._sep_asunto.setVisible(visible)

    def set_asunto(self, texto: str, user_edit: bool = False):
        if not user_edit and not self._asunto_usr_edited:
            self._inp_asunto.blockSignals(True)
            self._inp_asunto.setText(texto)
            self._inp_asunto.blockSignals(False)
            self._update_char_count()

    def get_asunto(self) -> str:
        return self._inp_asunto.text().strip()

    def get_contratante(self) -> str:
        return self._inp_contratante.text().strip()

    def get_cia(self) -> str:
        return self._cb_cia.currentText()

    def get_all_data(self) -> dict:
        polizas = [
            {"ramo": d["ramo_cb"].currentText(), "pol": d["pol_inp"].text().strip()}
            for d in self._pol_rows
        ]
        endosos = [
            {
                "ramo": d["ramo_cb"].currentText(),
                "pol":  d["pol_inp"].text().strip(),
                "end":  d["end_inp"].text().strip(),
                "mov":  d["mov_inp"].text().strip(),
            }
            for d in self._end_rows
        ]
        decls = [
            {"nro_decl": d["nro_inp"].text().strip(), "mes": d["mes_inp"].text().strip()}
            for d in self._decl_rows
        ]
        return {
            "contratante":  self._inp_contratante.text().strip(),
            "contacto":     self._inp_contacto.text().strip(),
            "cia":          self._cb_cia.currentText(),
            "vigencia_ini": self._inp_vig_ini.text().strip(),
            "vigencia_fin": self._inp_vig_fin.text().strip(),
            "mes_decl":     self._inp_mes.text().strip(),
            "polizas":      polizas,
            "endosos":      endosos,
            "declaraciones": decls,
        }

    def show_paste_error(self, msg: str):
        self._paste_error.setText(msg)
        self._paste_error.show()

    def apply_paste(self, datos: dict, cfg: ConfigLoader):
        self._paste_error.hide()
        if "contratante" in datos:
            self._inp_contratante.setText(datos["contratante"])
        if "contacto" in datos:
            self._inp_contacto.setText(datos["contacto"])
        if "aseguradora" in datos:
            idx = self._cb_cia.findText(datos["aseguradora"])
            if idx >= 0:
                self._cb_cia.setCurrentIndex(idx)
            else:
                self.show_paste_error(
                    f"CIA '{datos['aseguradora']}' no encontrada. Selecciónala manualmente."
                )
        if self._pol_rows:
            if "nro_poliza" in datos:
                self._pol_rows[0]["pol_inp"].setText(datos["nro_poliza"])
            if "ramo" in datos:
                idx = self._pol_rows[0]["ramo_cb"].findText(datos["ramo"])
                if idx >= 0: self._pol_rows[0]["ramo_cb"].setCurrentIndex(idx)
        if "vigencia_inicio" in datos:
            self._inp_vig_ini.setText(datos["vigencia_inicio"])
        if "vigencia_fin" in datos:
            self._inp_vig_fin.setText(datos["vigencia_fin"])
        self._asunto_usr_edited = False
        self.data_changed.emit()
