# coding: utf-8
"""
ui/main_window.py — Ventana principal de MailDeDespacho.

CAMBIOS respecto a iteración anterior:
  - Nueva lógica de navegación progresiva:
      1. Arranque: Línea de negocio visible + Tipo de plantilla (solo header)
         + Modo de envío (solo header con botones visibles pero sin L2 aún)
      2. Al seleccionar empresa: aparecen los botones L1 de Tipo de plantilla
      3. Al seleccionar L2 (radiobutton) + Modo de envío: aparece columna derecha
         con Vista previa activada por botón toggle
  - Vista previa en panel lateral (2ª columna) activada por QPushButton toggle
  - Sin parpadeo al seleccionar empresa: los bloques downstream se ocultan
    sin recrear widgets, solo show/hide
  - setFixedSize usa valores int desde QSSD (corregido TypeError)
"""

from __future__ import annotations
import logging
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QPoint
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QScrollArea, QFrame,
    QFileDialog, QRadioButton, QButtonGroup, QSplitter,
)

from theme import QSSD, build_qss
from svgs import SVG, apply_svg_icon
from config_loader import ConfigLoader, parse_clipboard_data
from template_engine import TemplateEngine, DespachoContext
from outlook_bridge import OutlookBridge, OutlookError

from ui.widgets.block_widget import BlockWidget
from ui.widgets.empresa_selector import EmpresaSelector
from ui.widgets.plantilla_selector import PlantillaSelector
from ui.widgets.modo_envio import ModoEnvio
from ui.widgets.datos_despacho import DatosDespacho
from ui.widgets.vista_previa import VistaPrevia
from ui.dialogs.outlook_dialog import OutlookWarningDialog, ErrorDialog

logger = logging.getLogger(__name__)

_ACCENT_MAP = {
    "RRGG":        (QSSD["accent_rrgg"],  QSSD["accent_rrgg_dark"],  QSSD["accent_rrgg_light"]),
    "Transportes": (QSSD["accent_trans"], QSSD["accent_trans_dark"], QSSD["accent_trans_light"]),
}


# =============================================================================
# TITLEBAR
# =============================================================================

class AppTitleBar(QWidget):
    """Barra de título personalizada sin marco nativo."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setObjectName("AppTitleBar")
        # CORRECCIÓN: int desde QSSD — evita TypeError setFixedHeight(str)
        self.setFixedHeight(QSSD["titlebar_fixed_height"])
        self._drag_pos: QPoint | None = None
        self._win = parent
        self._maximized = False
        self._build()

    def _build(self):
        lay = QHBoxLayout(self)
        lay.setContentsMargins(*QSSD["margins_titlebar_inner"])
        lay.setSpacing(QSSD["spacing_titlebar"])

        lbl = QLabel("MailDeDespacho")
        lbl.setObjectName("AppTitleLabel")
        lay.addWidget(lbl)
        lay.addStretch()

        # CORRECCIÓN: icon_size es tuple de int → QSize(*tuple) está bien
        icon_sz = QSize(*QSSD["titlebar_logo_size"])
        # CORRECCIÓN: btn_width es int → setFixedSize(int, int) correcto
        btn_w = QSSD["titlebar_btn_width"]
        btn_h = QSSD["titlebar_fixed_height"]

        for role, svg, slot in [
            ("titlebar-min",   SVG.MINIMIZAR, self._on_min),
            ("titlebar-max",   SVG.MAXIMIZAR, self._on_max),
            ("titlebar-close", SVG.CERRAR,    self._on_close),
        ]:
            btn = QPushButton()
            btn.setProperty("role", role)
            btn.setFixedSize(btn_w, btn_h)   # ambos int ✓
            apply_svg_icon(btn, svg, icon_sz, QSSD["text_on_dark"])
            btn.clicked.connect(slot)
            lay.addWidget(btn)

    def _on_min(self):   self._win.showMinimized()
    def _on_close(self): self._win.close()

    def _on_max(self):
        if self._win.isMaximized():
            self._win.showNormal()
        else:
            self._win.showMaximized()

    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPosition().toPoint() - self._win.frameGeometry().topLeft()

    def mouseMoveEvent(self, e: QMouseEvent):
        if self._drag_pos and e.buttons() == Qt.LeftButton:
            self._win.move(e.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, e: QMouseEvent):
        self._drag_pos = None

    def mouseDoubleClickEvent(self, e: QMouseEvent):
        self._on_max()


# =============================================================================
# VENTANA PRINCIPAL
# =============================================================================

class MainWindow(QWidget):
    """
    Ventana principal sin marco nativo.

    Layout de dos columnas (cuando preview está activo):
    ┌─ TitleBar ──────────────────────────────────────────────────────┐
    ├─ QSplitter ──────────────────────────────────────────────────────┤
    │  ┌─ Columna izquierda (scroll) ──┐  ┌─ Columna derecha ────────┐ │
    │  │  Bloques del formulario       │  │  Vista previa HTML       │ │
    │  └───────────────────────────────┘  └──────────────────────────┘ │
    └──────────────────────────────────────────────────────────────────┘

    Lógica de navegación progresiva (nueva):
      Estado 0 — Arranque:
        • Línea de negocio: visible con botones
        • Tipo de plantilla: visible SOLO el header/label (sin botones L1)
        • Modo de envío: visible con botones (pero deshabilitados hasta L2)

      Estado 1 — Empresa seleccionada:
        • Tipo de plantilla: aparecen botones L1

      Estado 2 — L1 + L2 seleccionados:
        • Tipo de plantilla: L2 visible
        • Modo de envío: botones habilitados

      Estado 3 — Modo de envío seleccionado:
        • Datos del despacho: visible
        • Botón "Ver preview" en barra de acciones: activo
        • Panel derecho: aparece al hacer clic en el botón toggle

    El formulario NO parpadea: los widgets se muestran/ocultan con
    show()/hide(), sin deleteLater() ni recreación de estructura.
    """

    def __init__(self) -> None:
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setMinimumSize(QSSD["app_min_width"], QSSD["app_min_height"])
        self.resize(QSSD["app_default_width"], QSSD["app_default_height"])
        self.setWindowTitle("MailDeDespacho")

        # Servicios
        self._cfg     = ConfigLoader()
        self._engine  = TemplateEngine()
        self._outlook = OutlookBridge()

        # Estado de navegación
        self._empresa:  str = ""
        self._tpl_l1:   str = ""
        self._tpl_l2:   str = ""
        self._modo:     str = ""
        self._msg_path: str = ""
        self._asunto_usr_edited: bool = False
        self._preview_visible: bool = False

        self._build_ui()
        self._apply_theme()
        self._set_nav_state(0)   # estado inicial

    # ── Construcción ──────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(*QSSD["margins_app_root"])
        root.setSpacing(QSSD["spacing_app_root"])

        # TitleBar
        root.addWidget(AppTitleBar(self))

        # Splitter horizontal (formulario | preview)
        self._splitter = QSplitter(Qt.Horizontal)
        self._splitter.setHandleWidth(1)
        self._splitter.setStyleSheet(
            f"QSplitter::handle {{ background-color: {QSSD['border_block']}; }}"
        )
        root.addWidget(self._splitter)

        # ── Columna izquierda: formulario ─────────────────────────────────────
        left = QWidget()
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(0, 0, 0, 0)
        left_lay.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_lay.addWidget(scroll)

        form = QWidget()
        self._form_lay = QVBoxLayout(form)
        self._form_lay.setContentsMargins(*QSSD["margins_scroll_content"])
        self._form_lay.setSpacing(QSSD["spacing_scroll_content"])
        scroll.setWidget(form)

        # Bloques del formulario
        self._build_blocks()
        self._form_lay.addStretch()

        self._splitter.addWidget(left)

        # ── Columna derecha: preview ──────────────────────────────────────────
        self._right_panel = QWidget()
        right_lay = QVBoxLayout(self._right_panel)
        right_lay.setContentsMargins(8, 8, 8, 8)
        right_lay.setSpacing(6)

        lbl_prev = QLabel("VISTA PREVIA DEL CORREO")
        lbl_prev.setObjectName("SLabel")
        right_lay.addWidget(lbl_prev)

        self._preview = VistaPrevia()
        right_lay.addWidget(self._preview)

        self._right_panel.hide()
        self._splitter.addWidget(self._right_panel)
        self._splitter.setStretchFactor(0, 3)
        self._splitter.setStretchFactor(1, 2)

    def _build_blocks(self):
        """Construye todos los bloques del formulario."""

        # ── Bloque 1: Línea de negocio ────────────────────────────────────────
        blk1 = BlockWidget("Línea de negocio")
        self._empresa_sel = EmpresaSelector()
        self._empresa_sel.empresa_changed.connect(self._on_empresa)
        blk1.add_widget(self._empresa_sel)
        self._form_lay.addWidget(blk1)

        # ── Bloque 2: Tipo de plantilla ───────────────────────────────────────
        # Siempre visible desde el arranque, pero L1 oculto hasta empresa sel.
        blk2 = BlockWidget("Tipo de plantilla")
        self._tpl_sel = PlantillaSelector()
        self._tpl_sel.l1_changed.connect(self._on_tpl_l1)
        self._tpl_sel.l2_changed.connect(self._on_tpl_l2)
        blk2.add_widget(self._tpl_sel)
        self._blk_tpl = blk2
        self._form_lay.addWidget(blk2)

        # ── Bloque 3: Modo de envío ───────────────────────────────────────────
        # Siempre visible, botones deshabilitados hasta L2.
        blk3 = BlockWidget("Modo de envío")
        self._modo_sel = ModoEnvio()
        self._modo_sel.modo_changed.connect(self._on_modo)
        blk3.add_widget(self._modo_sel)
        self._blk_modo = blk3
        self._form_lay.addWidget(blk3)

        # ── Bloque 4: Correo original .msg ────────────────────────────────────
        self._blk_msg = BlockWidget("Correo original (.msg)")
        self._build_msg_block()
        self._blk_msg.hide()
        self._form_lay.addWidget(self._blk_msg)

        # ── Bloque 5: Datos del despacho ──────────────────────────────────────
        self._blk_datos = BlockWidget("Datos del despacho")
        self._datos = DatosDespacho(self._cfg)
        self._datos.data_changed.connect(self._on_data_changed)
        self._datos.paste_requested.connect(self._on_paste)
        self._blk_datos.add_widget(self._datos)
        self._blk_datos.hide()
        self._form_lay.addWidget(self._blk_datos)

        # ── Barra de acciones ─────────────────────────────────────────────────
        self._bar_actions = self._build_action_bar()
        self._bar_actions.hide()
        self._form_lay.addWidget(self._bar_actions)

    def _build_msg_block(self):
        """Bloque .msg: selector de archivo + radio de asunto."""
        lay = QVBoxLayout()
        lay.setSpacing(8)

        self._btn_msg = QPushButton("  Seleccionar archivo .msg...")
        self._btn_msg.setProperty("role", "btn-paste")
        apply_svg_icon(self._btn_msg, SVG.ARCHIVO_MSG, QSize(16, 16), QSSD["text_muted"])
        self._btn_msg.clicked.connect(self._on_select_msg)
        lay.addWidget(self._btn_msg)

        radio_row = QHBoxLayout()
        radio_row.setSpacing(16)
        lbl_as = QLabel("Asunto:")
        lbl_as.setObjectName("FieldLabel")
        radio_row.addWidget(lbl_as)

        self._rb_original = QRadioButton("Mantener asunto original")
        self._rb_nuevo    = QRadioButton("Generar nuevo asunto")
        self._rb_original.setChecked(True)

        self._bg_asunto = QButtonGroup(self)
        self._bg_asunto.addButton(self._rb_original, 0)
        self._bg_asunto.addButton(self._rb_nuevo,    1)
        self._bg_asunto.idClicked.connect(self._on_asunto_opt)

        radio_row.addWidget(self._rb_original)
        radio_row.addWidget(self._rb_nuevo)
        radio_row.addStretch()
        lay.addLayout(radio_row)
        self._blk_msg.add_layout(lay)

    def _build_action_bar(self) -> QWidget:
        """Barra inferior: Limpiar | Preview toggle | Abrir en Outlook."""
        bar = QWidget()
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(0, 4, 0, 8)
        lay.setSpacing(8)

        # Limpiar
        self._btn_limpiar = QPushButton("  Limpiar")
        self._btn_limpiar.setProperty("role", "btn-secondary")
        apply_svg_icon(self._btn_limpiar, SVG.LIMPIAR, QSize(14, 14), QSSD["text_muted"])
        self._btn_limpiar.clicked.connect(self._on_limpiar)
        lay.addWidget(self._btn_limpiar)

        # Toggle preview
        self._btn_preview_toggle = QPushButton("  Vista previa")
        self._btn_preview_toggle.setProperty("role", "btn-secondary")
        apply_svg_icon(self._btn_preview_toggle, SVG.POLIZA, QSize(14, 14), QSSD["text_muted"])
        self._btn_preview_toggle.setCheckable(False)
        self._btn_preview_toggle.clicked.connect(self._on_toggle_preview)
        lay.addWidget(self._btn_preview_toggle)

        lay.addStretch()

        # Abrir en Outlook
        self._btn_outlook = QPushButton("  Abrir en Outlook")
        self._btn_outlook.setProperty("role", "btn-primary")
        apply_svg_icon(self._btn_outlook, SVG.OUTLOOK, QSize(15, 15), "#FFFFFF")
        self._btn_outlook.clicked.connect(self._on_abrir_outlook)
        lay.addWidget(self._btn_outlook)

        return bar

    # ── Tema ──────────────────────────────────────────────────────────────────

    def _apply_theme(self):
        self.setStyleSheet(build_qss())

    def _update_accent(self, empresa: str):
        from theme import QSSD as qssd
        accent, dark, light = _ACCENT_MAP.get(empresa, _ACCENT_MAP["RRGG"])
        updates = {
            "accent":              accent, "accent_dark":          dark,
            "accent_light":        light,  "btn_linea_sel_bg":     accent,
            "btn_linea_sel_border":accent,  "radio_opt_sel_bg":     light,
            "radio_opt_sel_border":accent,  "btn_primary_bg":       accent,
            "btn_primary_hover":   dark,    "btn_add_row_text":     accent,
            "btn_add_row_border":  accent,  "btn_add_row_hover_bg": light,
            "border_input_hover":  accent,  "border_input_focus":   accent,
            "radio_dot_sel_border":accent,  "radio_dot_sel_fill":   accent,
            "combo_item_hover_bg": accent,  "combo_item_sel_bg":    dark,
        }
        qssd.update(updates)
        self._apply_theme()

    # ── Lógica de estados de navegación ──────────────────────────────────────

    def _set_nav_state(self, state: int):
        """
        state 0 → arranque: empresa + tipo plantilla (sin L1) + modo (sin L2)
        state 1 → empresa seleccionada: L1 visible
        state 2 → L2 seleccionado: modo habilitado
        state 3 → modo seleccionado: datos + acciones visibles
        """
        if state == 0:
            # Tipo plantilla: bloque visible pero sin botones L1
            self._blk_tpl.show()
            self._tpl_sel.hide_all()          # método que oculta L1 y L2

            # Modo envío: bloque visible pero botones deshabilitados
            self._blk_modo.show()
            self._modo_sel.set_enabled(False)  # deshabilita los pushbuttons

            # Ocultar resto
            self._blk_msg.hide()
            self._blk_datos.hide()
            self._bar_actions.hide()
            self._right_panel.hide()
            self._preview_visible = False

        elif state == 1:
            # Empresa seleccionada: mostrar botones L1
            self._tpl_sel.show_l1()
            # Modo sigue deshabilitado hasta L2
            self._modo_sel.set_enabled(False)
            # Limpiar downstream
            self._blk_msg.hide()
            self._blk_datos.hide()
            self._bar_actions.hide()
            self._right_panel.hide()
            self._preview_visible = False

        elif state == 2:
            # L2 seleccionado: habilitar modo
            self._modo_sel.set_enabled(True)
            # Datos siguen ocultos hasta que se elija modo
            self._blk_msg.hide()
            self._blk_datos.hide()
            self._bar_actions.hide()

        elif state == 3:
            # Modo elegido: mostrar datos y acciones
            if self._modo == "reply":
                self._blk_msg.show()
            else:
                self._blk_msg.hide()
            self._blk_datos.show()
            self._bar_actions.show()

    # ── Señales de empresa ────────────────────────────────────────────────────

    def _on_empresa(self, empresa: str):
        prev = self._empresa
        self._empresa = empresa
        self._tpl_l1  = ""
        self._tpl_l2  = ""
        self._modo    = ""
        self._msg_path = ""
        self._asunto_usr_edited = False

        # Actualizar acento sin parpadeo (solo QSS, no recrear widgets)
        self._update_accent(empresa)

        # Actualizar opciones L1 en el selector sin show/hide de la ventana
        self._tpl_sel.set_empresa(empresa)

        # Reset de datos (blockSignals interno)
        self._datos.hard_reset()
        self._preview.clear()

        # Resetear modo selector
        self._modo_sel.reset()

        # Ir al estado 1
        self._set_nav_state(1)

    # ── Señales de plantilla ──────────────────────────────────────────────────

    def _on_tpl_l1(self, l1: str):
        prev_l1 = self._tpl_l1
        self._tpl_l1 = l1
        self._tpl_l2 = ""
        self._modo   = ""
        self._asunto_usr_edited = False

        if prev_l1 and prev_l1 != l1:
            self._datos.soft_reset_for_l1(l1)

        self._modo_sel.reset()
        self._set_nav_state(1)   # L1 elegido pero no L2 aún → modo deshabilitado

    def _on_tpl_l2(self, l2: str):
        prev_l2 = self._tpl_l2
        self._tpl_l2 = l2
        self._asunto_usr_edited = False

        if prev_l2 and prev_l2 != l2:
            self._datos.soft_reset_for_l2(self._tpl_l1, prev_l2, l2)

        # Si hay modo ya elegido, actualizar campos y preview
        if self._modo:
            self._datos.adapt_fields(
                tpl_l1=self._tpl_l1,
                tpl_l2=l2,
                cia=self._datos.get_cia(),
            )
            self._refresh_asunto()
            self._refresh_preview()

        self._set_nav_state(2)   # L2 elegido → modo habilitado

    # ── Señales de modo de envío ──────────────────────────────────────────────

    def _on_modo(self, modo: str):
        self._modo = modo
        self._datos.adapt_fields(
            tpl_l1=self._tpl_l1,
            tpl_l2=self._tpl_l2,
            cia=self._datos.get_cia(),
        )
        self._refresh_asunto()
        self._set_nav_state(3)
        # Si preview estaba abierto, refrescar
        if self._preview_visible:
            self._refresh_preview()

    def _on_asunto_opt(self, btn_id: int):
        self._refresh_asunto()

    def _on_select_msg(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar correo original", "",
            "Mensajes de Outlook (*.msg);;Todos los archivos (*.*)"
        )
        if path:
            self._msg_path = path
            self._btn_msg.setText(f"  {Path(path).name}")
            apply_svg_icon(self._btn_msg, SVG.ARCHIVO_MSG,
                           QSize(16, 16), QSSD["accent"])

    def _on_paste(self):
        text = QApplication.clipboard().text()
        ok, datos, error = parse_clipboard_data(text)
        if not ok:
            self._datos.show_paste_error(error)
            return
        self._datos.apply_paste(datos, self._cfg)

    def _on_limpiar(self):
        self._datos.hard_reset()
        self._asunto_usr_edited = False
        self._preview.clear()
        self._refresh_asunto()

    def _on_toggle_preview(self):
        """Muestra/oculta el panel derecho de vista previa."""
        self._preview_visible = not self._preview_visible
        self._right_panel.setVisible(self._preview_visible)
        if self._preview_visible:
            self._btn_preview_toggle.setText("  Ocultar preview")
            self._refresh_preview()
        else:
            self._btn_preview_toggle.setText("  Vista previa")

    def _on_data_changed(self):
        self._refresh_asunto()
        if self._preview_visible:
            self._refresh_preview()

    # ── Acción principal ──────────────────────────────────────────────────────

    def _on_abrir_outlook(self):
        if not self._validate():
            return

        ctx  = self._build_context()
        html = self._engine.render(ctx)
        asunto = self._datos.get_asunto()

        dlg = OutlookWarningDialog(self)
        try:
            if self._modo == "nuevo":
                self._outlook.nuevo_correo(asunto=asunto, html_body=html)
            else:
                ok, err = OutlookBridge.validate_msg_file(self._msg_path)
                if not ok:
                    self._show_error(err)
                    return
                mantener = self._rb_original.isChecked()
                self._outlook.responder_a_todos(
                    msg_path=self._msg_path,
                    asunto=asunto,
                    html_body=html,
                    mantener_asunto_original=mantener,
                )
            dlg.exec()
        except OutlookError as e:
            self._show_error(str(e))

    # ── Validación ────────────────────────────────────────────────────────────

    def _validate(self) -> bool:
        if not all([self._empresa, self._tpl_l1, self._tpl_l2, self._modo]):
            self._show_error("Completa todas las selecciones antes de continuar.")
            return False
        if self._modo == "reply" and not self._msg_path:
            self._show_error(
                "Debes seleccionar el archivo .msg original\n"
                "para usar 'Responder a todos'."
            )
            return False
        if not self._datos.get_contratante():
            self._show_error("El campo 'Nombre contratante / asegurado' es obligatorio.")
            return False
        return True

    # ── Refresh asunto y preview ──────────────────────────────────────────────

    def _should_show_asunto(self) -> bool:
        if self._modo == "nuevo":
            return True
        if self._modo == "reply":
            return self._rb_nuevo.isChecked()
        return False

    def _refresh_asunto(self):
        mostrar = self._should_show_asunto()
        self._datos.set_asunto_visible(mostrar)
        if mostrar and not self._asunto_usr_edited:
            self._datos.set_asunto(self._build_asunto_auto(), user_edit=False)

    def _build_asunto_auto(self) -> str:
        d = self._datos.get_all_data()
        cli  = d.get("contratante") or "…"
        cia  = d.get("cia")         or "…"
        pols = d.get("polizas", [])
        ends = d.get("endosos", [])
        ramo = (pols[0].get("ramo") if pols else "") or (ends[0].get("ramo") if ends else "") or "…"
        pol  = (pols[0].get("pol")  if pols else "") or (ends[0].get("pol")  if ends else "") or "…"
        vi   = d.get("vigencia_ini") or "…"
        vf   = d.get("vigencia_fin") or "…"
        mes  = d.get("mes_decl")     or "…"
        mov  = (ends[0].get("mov") if ends else "") or "…"

        if self._tpl_l1 == "Declaración mensual":
            return f"DESPACHO DECLARACIÓN MENSUAL | {cli} | {cia} | {ramo} Pól. {pol} | {mes}"
        if self._tpl_l1 == "Endoso":
            return f"DESPACHO DE ENDOSO | {cli} | {cia} | {ramo} Pól. {pol} | {mov}"
        if "programa" in self._tpl_l2.lower():
            return f"DESPACHO PROGRAMA DE SEGUROS | {cli} | {cia} | {vi}–{vf}"
        return f"DESPACHO DE PÓLIZA | {cli} | {cia} | {ramo} Pól. {pol} | {vi}–{vf}"

    def _refresh_preview(self):
        if not self._modo:
            return
        ctx  = self._build_context()
        html = self._engine.render(ctx)
        self._preview.set_html(html)

    def _build_context(self) -> DespachoContext:
        d = self._datos.get_all_data()
        accent, dark, _ = _ACCENT_MAP.get(self._empresa, _ACCENT_MAP["RRGG"])
        return DespachoContext(
            empresa=self._empresa, tpl_l1=self._tpl_l1, tpl_l2=self._tpl_l2,
            contratante=d.get("contratante", ""), contacto=d.get("contacto", ""),
            cia=d.get("cia", ""), vigencia_ini=d.get("vigencia_ini", ""),
            vigencia_fin=d.get("vigencia_fin", ""), mes_decl=d.get("mes_decl", ""),
            polizas=d.get("polizas", []), endosos=d.get("endosos", []),
            declaraciones=d.get("declaraciones", []),
            label_endoso=self._cfg.label_endoso(d.get("cia", "")),
            asunto=self._datos.get_asunto(),
            color_acento=accent, color_acento_dark=dark,
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _show_error(self, msg: str):
        ErrorDialog(msg, self).exec()

    def asunto_manually_edited(self):
        self._asunto_usr_edited = True

    def asunto_reset_manual(self):
        self._asunto_usr_edited = False
