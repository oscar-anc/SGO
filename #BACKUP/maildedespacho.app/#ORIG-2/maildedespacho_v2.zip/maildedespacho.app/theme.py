# coding: utf-8
"""
theme.py — Tema centralizado: Vivaldi Dark 4.x

Paleta base del tema "Dark" built-in de Vivaldi Browser versión 4.x:
  baseBg      #2e2f37  → fondo principal
  accentBg    #44454d  → superficies elevadas / titlebar
  baseFg      #d3d9e3  → texto principal
  highlightBg #6590fd  → color de acento / highlight
  borderRadius 6px     → radio nativo del tema

REGLA ESTRICTA DE TIPOS — elimina todos los TypeError:
  int  → valores usados en Python: setFixedSize(), setFixedHeight(),
          setContentsMargins(), resize(), o como {c['key']}px en QSS
  str  → valores CSS completos: '1px', '6px 10px', 'none', '#hex'
  No mezclar. Nunca poner 'px' en valores que van al código Python.
"""

from PySide6.QtGui import QPalette, QColor

QSSD: dict = {

    # =========================================================================
    # COLORES — PALETA VIVALDI DARK 4.x
    # =========================================================================

    # ── Fondos jerárquicos ────────────────────────────────────────────────────
    'app_bg':           '#2e2f37',   # baseBg — el nivel más oscuro
    'surface_raised':   '#363740',   # bloques / cards
    'surface':          '#3d3e48',   # inputs: QLineEdit, QComboBox
    'surface_alt':      '#44454d',   # accentBg — hover items dropdown
    'surface_card':     '#363740',

    # ── Texto ─────────────────────────────────────────────────────────────────
    'text_primary':     '#d3d9e3',   # baseFg
    'text_on_dark':     '#d3d9e3',
    'text_muted':       '#8a93a8',
    'text_disabled':    '#56575f',
    'text_placeholder': '#5e6270',
    'text_on_accent':   '#ffffff',
    'text_label':       '#9199aa',

    # ── Constantes CSS ────────────────────────────────────────────────────────
    'css_none':         'none',
    'css_transparent':  'transparent',
    'css_zero':         '0',
    'css_image_none':   'none',
    'css_outline_none': 'none',
    'align_left':       'left',
    'align_center':     'center',
    'fw_bold':          'bold',
    'fw_normal':        'normal',

    # ── Acento RRGG (highlightBg Vivaldi Dark = #6590fd) ─────────────────────
    'accent_rrgg':       '#6590fd',
    'accent_rrgg_dark':  '#4a72e8',
    'accent_rrgg_light': '#252d4a',

    # ── Acento Transportes (teal complementario) ──────────────────────────────
    'accent_trans':       '#56b4a0',
    'accent_trans_dark':  '#3d9484',
    'accent_trans_light': '#1b3030',

    # ── Acento activo (se sobreescribe en Python según empresa) ───────────────
    'accent':       '#6590fd',
    'accent_dark':  '#4a72e8',
    'accent_light': '#252d4a',

    # ── Bordes ────────────────────────────────────────────────────────────────
    'border_input':       '#4a4b56',
    'border_input_hover': '#6590fd',
    'border_input_focus': '#6590fd',
    'border_block':       '#42434d',

    # ── TitleBar ──────────────────────────────────────────────────────────────
    'titlebar_bg':               '#26272e',
    'titlebar_btn_text':         '#d3d9e3',
    'titlebar_btn_hover_bg':     '#6590fd',
    'titlebar_btn_pressed_bg':   '#4a72e8',
    'titlebar_close_hover_bg':   '#c42b1c',
    'titlebar_close_pressed_bg': '#a01e10',

    # ── Bloques ───────────────────────────────────────────────────────────────
    'block_header_text': '#9199aa',
    'block_body_bg':     '#363740',
    'block_body_border': '#42434d',

    # ── Botones grandes ───────────────────────────────────────────────────────
    'btn_linea_bg':       '#3d3e48',
    'btn_linea_border':   '#4a4b56',
    'btn_linea_text':     '#9199aa',
    'btn_linea_hover_bg': '#44454d',
    'btn_linea_sel_bg':   '#6590fd',
    'btn_linea_sel_text': '#ffffff',
    'btn_linea_sel_border':'#6590fd',

    # ── Radio-cards L2 ────────────────────────────────────────────────────────
    'radio_opt_bg':         '#3d3e48',
    'radio_opt_border':     '#4a4b56',
    'radio_opt_hover_bg':   '#44454d',
    'radio_opt_sel_bg':     '#252d4a',
    'radio_opt_sel_border': '#6590fd',
    'radio_dot_border':     '#5e6270',
    'radio_dot_sel_border': '#6590fd',
    'radio_dot_sel_fill':   '#6590fd',

    # ── Botón Agregar ─────────────────────────────────────────────────────────
    'btn_add_row_text':            '#6590fd',
    'btn_add_row_border':          '#6590fd',
    'btn_add_row_hover_bg':        '#252d4a',
    'btn_add_row_disabled_text':   '#56575f',
    'btn_add_row_disabled_border': '#42434d',

    # ── Botón Eliminar ────────────────────────────────────────────────────────
    'btn_del_bg':        '#3d3e48',
    'btn_del_border':    '#4a4b56',
    'btn_del_icon':      '#8a93a8',
    'btn_del_hover_bg':  '#3a2020',
    'btn_del_hover_icon':'#e06c75',

    # ── Botón primario ────────────────────────────────────────────────────────
    'btn_primary_bg':    '#6590fd',
    'btn_primary_hover': '#4a72e8',
    'btn_primary_text':  '#ffffff',

    # ── Botón secundario ──────────────────────────────────────────────────────
    'btn_secondary_bg':     '#3d3e48',
    'btn_secondary_border': '#4a4b56',
    'btn_secondary_text':   '#d3d9e3',
    'btn_secondary_hover':  '#44454d',

    # ── Botón Pegar ───────────────────────────────────────────────────────────
    'btn_paste_bg':       '#3d3e48',
    'btn_paste_border':   '#4a4b56',
    'btn_paste_text':     '#9199aa',
    'btn_paste_hover_bg': '#44454d',

    # ── QComboBox dropdown ────────────────────────────────────────────────────
    'combo_dropdown_bg':      '#3d3e48',
    'combo_dropdown_border':  '#4a4b56',
    'combo_item_hover_bg':    '#6590fd',
    'combo_item_hover_text':  '#ffffff',
    'combo_item_sel_bg':      '#4a72e8',
    'combo_item_sel_text':    '#ffffff',

    # ── Scrollbar ─────────────────────────────────────────────────────────────
    'scrollbar_track':          '#2e2f37',
    'scrollbar_handle':         '#4a4b56',
    'scrollbar_handle_hover':   '#6590fd',
    'scrollbar_handle_pressed': '#4a72e8',
    'scrollbar_handle_radius':  '3px',   # str → QSS directo
    'scrollbar_margin':         '1px',   # str → QSS directo

    # ── Asunto ────────────────────────────────────────────────────────────────
    'asunto_bg':         '#3d3e48',
    'asunto_border':     '#4a4b56',
    'asunto_char_normal':'#8a93a8',
    'asunto_char_warn':  '#e5a550',
    'asunto_char_over':  '#e06c75',

    # ── Vista previa ──────────────────────────────────────────────────────────
    'preview_bg':          '#2e2f37',
    'preview_border':      '#42434d',
    'preview_empty_text':  '#56575f',

    # ── CustomMessageBox ──────────────────────────────────────────────────────
    'msg_titlebar_bg':   '#26272e',
    'msg_titlebar_text': '#d3d9e3',
    'msg_body_bg':       '#363740',
    'msg_body_text':     '#d3d9e3',
    'msg_border':        '#42434d',
    'msg_icon_color':    '#e5a550',
    'msg_btn_ok_bg':     '#6590fd',
    'msg_btn_ok_hover':  '#4a72e8',
    'msg_btn_ok_text':   '#ffffff',

    # ── Inline warn / error ───────────────────────────────────────────────────
    'inline_warn_bg':     '#3a3020',
    'inline_warn_border': '#e5a550',
    'inline_warn_text':   '#e5a550',
    'inline_error_bg':    '#3a2020',
    'inline_error_border':'#e06c75',
    'inline_error_text':  '#e06c75',

    # =========================================================================
    # TIPOGRAFÍA — str (valores CSS)
    # =========================================================================
    'font_family':      'Segoe UI',
    'font_size_base':   '9pt',
    'font_size_button': '9pt',
    'font_size_small':  '8pt',
    'font_size_label':  '8pt',
    'font_size_nav':    '11px',

    # =========================================================================
    # BORDES — str (valores CSS completos)
    # =========================================================================
    'border_width_input':          '1px',
    'border_width_combo':          '1px',
    'border_width_combo_dropdown': '1px',
    'border_width_block':          '1px',
    'border_width_btn_linea':      '1px',
    'border_width_btn_add':        '1px',
    'border_width_btn_del':        '1px',
    'border_width_btn_secondary':  '1px',
    'border_width_msg':            '1px',
    'border_width_asunto':         '1px',
    'border_width_preview':        '1px',

    # ── Border radius — str (CSS) ─────────────────────────────────────────────
    'radius_input':        '6px',
    'radius_combo':        '6px',
    'radius_btn':          '6px',
    'radius_btn_linea':    '6px',
    'radius_btn_add':      '6px',
    'radius_btn_del':      '6px',
    'radius_radio_opt':    '6px',
    'radius_block':        '8px',
    'radius_msg':          '8px',
    'radius_msg_titlebar': '8px 8px 0 0',
    'radius_msg_body':     '0 0 8px 8px',
    'radius_msg_btn':      '6px',
    'radius_preview':      '6px',
    'radius_asunto':       '6px',
    'radius_zero':         '0px',

    # ── Letter spacing ────────────────────────────────────────────────────────
    'block_label_letter_spacing': '0.5px',

    # =========================================================================
    # PADDING — str (CSS shorthand, van directo en QSS)
    # =========================================================================
    'padding_input':           '6px 10px',
    'padding_btn_linea':       '8px 14px',
    'padding_btn_add':         '5px 12px',
    'padding_btn_primary':     '8px 18px',
    'padding_btn_secondary':   '8px 12px',
    'padding_btn_paste':       '6px 12px',
    'padding_msg_btn':         '8px 20px',
    'padding_zero_h':          '0px',

    # =========================================================================
    # SIZING — REGLA DE TIPOS ESTRICTA
    #
    # int → se usa en Python (setFixedSize, setFixedHeight, resize, margins)
    #       O en QSS como {c['key']}px  (sin 'px' aquí)
    # str → SOLO si va directo en QSS con px ya incluido (shorthand)
    #
    # CRÍTICO: titlebar_btn_width y titlebar_fixed_height DEBEN ser int.
    # El error original TypeError:'setFixedSize' called with (str, int)
    # ocurría porque eran str '36'. Aquí son int 36.
    # =========================================================================

    # ── TitleBar — DEBEN ser int (Python: setFixedSize, setFixedHeight) ───────
    'titlebar_height':       36,   # int ← Python: bar.setFixedHeight(36)
    'titlebar_fixed_height': 36,   # int ← Python: setFixedHeight(36)
    'titlebar_btn_width':    36,   # int ← Python: btn.setFixedSize(36, 36)

    # ── Inputs — int (QSS: min-height: {c['input_min_height']}px) ────────────
    'input_min_height':  28,
    'combo_min_height':  28,
    'combo_arrow_width': 22,
    'combo_item_height': 26,
    'combo_arrow_size':  12,

    # ── Botones — int ─────────────────────────────────────────────────────────
    'btn_min_height':           30,
    'btn_linea_min_height':     48,    # reducido (era 64)
    'btn_del_size':             28,    # Python: setFixedSize(28, 28)
    'btn_add_min_height':       26,
    'btn_primary_min_height':   34,
    'btn_primary_min_width':    140,
    'btn_secondary_min_height': 34,
    'btn_paste_min_height':     28,
    'msg_btn_min_height':       34,
    'msg_btn_min_width':        110,

    # ── Scrollbar — int ───────────────────────────────────────────────────────
    'scrollbar_width':      7,
    'scrollbar_handle_min': 28,

    # ── Diálogo — int ─────────────────────────────────────────────────────────
    'msg_box_min_width': 400,
    'msg_box_max_width': 460,

    # =========================================================================
    # LAYOUT — Python only (int y tuples de int)
    # NUNCA se usan en QSS. Solo en setContentsMargins(*t), resize(), etc.
    # =========================================================================

    'app_min_width':     800,
    'app_min_height':    600,
    'app_default_width': 900,
    'app_default_height':860,

    'margins_app_root':       (0, 0, 0, 0),
    'spacing_app_root':       0,
    'margins_titlebar_inner': (12, 0, 4, 0),
    'spacing_titlebar':       8,
    'titlebar_logo_size':     (20, 20),

    'margins_scroll_content': (14, 14, 14, 14),
    'spacing_scroll_content': 10,

    'margins_block_outer':    (0, 0, 0, 0),
    'spacing_block_body':     8,

    'btn_linea_icon_size':    (20, 20),
    'btn_linea_spacing':      8,

    'radio_opt_grid_cols':    2,
    'radio_opt_grid_spacing': 8,
    'radio_opt_min_height':   44,

    'margins_datos_section':  (0, 0, 0, 0),
    'spacing_datos_fields':   8,
    'spacing_field_inline':   8,
    'field_label_margin_bottom': 3,

    'dyn_row_spacing':        8,
    'dyn_row_margin_bottom':  6,

    'msg_icon_circle_size':   (40, 40),
    'margins_msg_titlebar':   (14, 0, 6, 0),
    'spacing_msg_titlebar':   8,
    'margins_msg_body':       (20, 16, 20, 14),
    'spacing_msg_body':       14,
    'margins_msg_buttons':    (0, 6, 0, 0),
    'spacing_msg_buttons':    8,

    'preview_min_height':       220,
    'margins_preview':          (0, 0, 0, 0),
    'preview_panel_min_width':  340,
    'preview_panel_max_width':  480,
}


def build_qss() -> str:
    c = QSSD
    return f"""

    /* S01 RESET GLOBAL */
    QWidget {{
        background-color: {c['app_bg']};
        color:            {c['text_primary']};
        font-family:      "{c['font_family']}";
        font-size:        {c['font_size_base']};
        font-weight:      {c['fw_normal']};
        outline:          {c['css_none']};
    }}

    /* S02 SCROLL AREA */
    QScrollArea {{ background-color: {c['app_bg']}; border: {c['css_none']}; }}
    QScrollArea > QWidget > QWidget {{ background-color: {c['app_bg']}; }}

    /* S03 BLOQUES */
    #BlockWidget {{
        background-color: {c['block_body_bg']};
        border:           {c['border_width_block']} solid {c['block_body_border']};
        border-radius:    {c['radius_block']};
    }}
    #SLabel {{
        color:          {c['block_header_text']};
        font-size:      {c['font_size_small']};
        font-weight:    {c['fw_bold']};
        letter-spacing: {c['block_label_letter_spacing']};
        background:     {c['css_transparent']};
    }}
    #FieldLabel {{
        color:       {c['text_label']};
        font-size:   {c['font_size_label']};
        font-weight: {c['fw_normal']};
        background:  {c['css_transparent']};
    }}

    /* S04 QLINEEDIT */
    QLineEdit {{
        background-color: {c['surface']};
        color:            {c['text_primary']};
        border:           {c['border_width_input']} solid {c['border_input']};
        border-radius:    {c['radius_input']};
        padding:          {c['padding_input']};
        min-height:       {c['input_min_height']}px;
        selection-background-color: {c['accent']};
        selection-color:            {c['text_on_accent']};
    }}
    QLineEdit:hover   {{ border-color: {c['border_input_hover']}; }}
    QLineEdit:focus   {{ border-color: {c['border_input_focus']}; }}
    QLineEdit:disabled {{
        background-color: {c['surface_alt']};
        color:            {c['text_disabled']};
        border-color:     {c['border_input']};
    }}
    QLineEdit#AsuntoEdit {{
        background-color: {c['asunto_bg']};
        border:           {c['border_width_asunto']} solid {c['asunto_border']};
        border-radius:    {c['radius_asunto']};
    }}

    /* S05 QCOMBOBOX */
    QComboBox {{
        background-color: {c['surface']};
        color:            {c['text_primary']};
        border:           {c['border_width_combo']} solid {c['border_input']};
        border-radius:    {c['radius_combo']};
        padding:          {c['padding_input']};
        min-height:       {c['combo_min_height']}px;
        selection-background-color: {c['accent']};
    }}
    QComboBox:hover    {{ border-color: {c['border_input_hover']}; }}
    QComboBox:focus    {{ border-color: {c['border_input_focus']}; }}
    QComboBox:disabled {{ background-color: {c['surface_alt']}; color: {c['text_disabled']}; }}
    QComboBox::drop-down {{ border: {c['css_none']}; width: {c['combo_arrow_width']}px; }}
    QComboBox::down-arrow {{ width: {c['combo_arrow_size']}px; height: {c['combo_arrow_size']}px; image: {c['css_image_none']}; }}
    QComboBox QAbstractItemView {{
        background-color: {c['combo_dropdown_bg']};
        color:            {c['text_primary']};
        border:           {c['border_width_combo_dropdown']} solid {c['combo_dropdown_border']};
        border-radius:    {c['radius_zero']};
        outline:          {c['css_outline_none']};
        padding:          2px;
    }}
    QComboBox QAbstractItemView::item {{ min-height: {c['combo_item_height']}px; padding: 3px 8px; color: {c['text_primary']}; }}
    QComboBox QAbstractItemView::item:hover    {{ background-color: {c['combo_item_hover_bg']}; color: {c['combo_item_hover_text']}; }}
    QComboBox QAbstractItemView::item:selected {{ background-color: {c['combo_item_sel_bg']};   color: {c['combo_item_sel_text']}; }}

    /* S06 BOTONES GRANDES */
    QPushButton[role="btn-linea"] {{
        background-color: {c['btn_linea_bg']};
        color:            {c['btn_linea_text']};
        border:           {c['border_width_btn_linea']} solid {c['btn_linea_border']};
        border-radius:    {c['radius_btn_linea']};
        padding:          {c['padding_btn_linea']};
        min-height:       {c['btn_linea_min_height']}px;
        font-weight:      {c['fw_bold']};
        font-size:        {c['font_size_button']};
        text-align:       {c['align_center']};
    }}
    QPushButton[role="btn-linea"]:hover {{ background-color: {c['btn_linea_hover_bg']}; border-color: {c['border_input_hover']}; }}
    QPushButton[role="btn-linea"][selected="true"] {{
        background-color: {c['btn_linea_sel_bg']};
        color:            {c['btn_linea_sel_text']};
        border-color:     {c['btn_linea_sel_border']};
    }}
    QPushButton[role="btn-tpl-l1"] {{
        background-color: {c['btn_linea_bg']};
        color:            {c['btn_linea_text']};
        border:           {c['border_width_btn_linea']} solid {c['btn_linea_border']};
        border-radius:    {c['radius_btn_linea']};
        padding:          6px 12px;
        min-height:       42px;
        font-weight:      {c['fw_bold']};
        font-size:        {c['font_size_button']};
        text-align:       {c['align_center']};
    }}
    QPushButton[role="btn-tpl-l1"]:hover {{ background-color: {c['btn_linea_hover_bg']}; border-color: {c['border_input_hover']}; }}
    QPushButton[role="btn-tpl-l1"][selected="true"] {{
        background-color: {c['btn_linea_sel_bg']};
        color:            {c['btn_linea_sel_text']};
        border-color:     {c['btn_linea_sel_border']};
    }}

    /* S07 RADIO-CARDS L2 */
    QFrame[role="radio-opt"] {{
        background-color: {c['radio_opt_bg']};
        border:           1px solid {c['radio_opt_border']};
        border-radius:    {c['radius_radio_opt']};
    }}
    QFrame[role="radio-opt"]:hover {{ background-color: {c['radio_opt_hover_bg']}; border-color: {c['border_input_hover']}; }}
    QFrame[role="radio-opt"][selected="true"] {{ background-color: {c['radio_opt_sel_bg']}; border-color: {c['radio_opt_sel_border']}; }}
    QFrame[role="radio-opt"] QRadioButton {{
        background-color: {c['css_transparent']};
        color:  {c['text_primary']};
        font-size: {c['font_size_button']};
        font-weight: {c['fw_bold']};
        spacing: 8px;
    }}
    QFrame[role="radio-opt"] QRadioButton::indicator {{
        width: 13px; height: 13px; border-radius: 7px;
        border: 2px solid {c['radio_dot_border']}; background: {c['surface']};
    }}
    QFrame[role="radio-opt"] QRadioButton::indicator:checked {{
        border-color: {c['radio_dot_sel_border']}; background: {c['radio_dot_sel_fill']};
    }}

    /* S08 BOTÓN AGREGAR */
    QPushButton[role="btn-add-row"] {{
        background-color: {c['css_transparent']};
        color:            {c['btn_add_row_text']};
        border:           {c['border_width_btn_add']} dashed {c['btn_add_row_border']};
        border-radius:    {c['radius_btn_add']};
        padding:          {c['padding_btn_add']};
        min-height:       {c['btn_add_min_height']}px;
        font-size:        {c['font_size_button']};
        text-align:       {c['align_left']};
    }}
    QPushButton[role="btn-add-row"]:hover    {{ background-color: {c['btn_add_row_hover_bg']}; }}
    QPushButton[role="btn-add-row"]:disabled {{ color: {c['btn_add_row_disabled_text']}; border-color: {c['btn_add_row_disabled_border']}; background: {c['css_transparent']}; }}

    /* S09 BOTÓN ELIMINAR */
    QPushButton[role="btn-del-row"] {{
        background-color: {c['btn_del_bg']};
        border:           {c['border_width_btn_del']} solid {c['btn_del_border']};
        border-radius:    {c['radius_btn_del']};
        min-width:  {c['btn_del_size']}px; max-width:  {c['btn_del_size']}px;
        min-height: {c['btn_del_size']}px; max-height: {c['btn_del_size']}px;
        padding:    {c['padding_zero_h']};
    }}
    QPushButton[role="btn-del-row"]:hover {{ background-color: {c['btn_del_hover_bg']}; border-color: {c['inline_error_border']}; }}

    /* S10 BOTONES DE ACCIÓN */
    QPushButton[role="btn-primary"] {{
        background-color: {c['btn_primary_bg']};
        color:            {c['btn_primary_text']};
        border:           {c['css_none']};
        border-radius:    {c['radius_btn']};
        padding:          {c['padding_btn_primary']};
        min-height:       {c['btn_primary_min_height']}px;
        min-width:        {c['btn_primary_min_width']}px;
        font-weight:      {c['fw_bold']};
        font-size:        {c['font_size_button']};
    }}
    QPushButton[role="btn-primary"]:hover   {{ background-color: {c['btn_primary_hover']}; }}
    QPushButton[role="btn-primary"]:pressed {{ background-color: {c['accent_dark']}; }}

    QPushButton[role="btn-secondary"] {{
        background-color: {c['btn_secondary_bg']};
        color:            {c['btn_secondary_text']};
        border:           {c['border_width_btn_secondary']} solid {c['btn_secondary_border']};
        border-radius:    {c['radius_btn']};
        padding:          {c['padding_btn_secondary']};
        min-height:       {c['btn_secondary_min_height']}px;
        font-size:        {c['font_size_button']};
    }}
    QPushButton[role="btn-secondary"]:hover {{ background-color: {c['btn_secondary_hover']}; }}

    QPushButton[role="btn-paste"] {{
        background-color: {c['btn_paste_bg']};
        color:            {c['btn_paste_text']};
        border:           1px solid {c['btn_paste_border']};
        border-radius:    {c['radius_btn']};
        padding:          {c['padding_btn_paste']};
        min-height:       {c['btn_paste_min_height']}px;
        font-size:        {c['font_size_button']};
    }}
    QPushButton[role="btn-paste"]:hover {{ background-color: {c['btn_paste_hover_bg']}; }}

    /* S11 TITLEBAR */
    #AppTitleBar {{ background-color: {c['titlebar_bg']}; min-height: {c['titlebar_height']}px; max-height: {c['titlebar_height']}px; }}
    #AppTitleLabel {{ color: {c['text_on_dark']}; font-weight: {c['fw_bold']}; font-size: {c['font_size_button']}; background-color: {c['css_transparent']}; }}
    QPushButton[role="titlebar-min"], QPushButton[role="titlebar-max"] {{
        background-color: {c['css_transparent']}; color: {c['titlebar_btn_text']}; border: {c['css_none']};
        font-size: {c['font_size_nav']};
        min-width: {c['titlebar_btn_width']}px; max-width: {c['titlebar_btn_width']}px;
        min-height: {c['titlebar_height']}px; max-height: {c['titlebar_height']}px;
        border-radius: {c['radius_zero']}; padding: {c['padding_zero_h']};
    }}
    QPushButton[role="titlebar-min"]:hover, QPushButton[role="titlebar-max"]:hover {{ background-color: {c['titlebar_btn_hover_bg']}; }}
    QPushButton[role="titlebar-close"] {{
        background-color: {c['css_transparent']}; color: {c['titlebar_btn_text']}; border: {c['css_none']};
        font-size: {c['font_size_nav']};
        min-width: {c['titlebar_btn_width']}px; max-width: {c['titlebar_btn_width']}px;
        min-height: {c['titlebar_height']}px; max-height: {c['titlebar_height']}px;
        border-radius: {c['radius_zero']}; padding: {c['padding_zero_h']};
    }}
    QPushButton[role="titlebar-close"]:hover   {{ background-color: {c['titlebar_close_hover_bg']}; }}
    QPushButton[role="titlebar-close"]:pressed {{ background-color: {c['titlebar_close_pressed_bg']}; }}

    /* S12 MESSAGEBOX */
    #MsgFrame {{ background-color: {c['msg_body_bg']}; border: {c['border_width_msg']} solid {c['msg_border']}; border-radius: {c['radius_msg']}; }}
    #MsgTitleBar {{ background-color: {c['msg_titlebar_bg']}; border-radius: {c['radius_msg_titlebar']}; }}
    #MsgTitleLabel {{ color: {c['msg_titlebar_text']}; font-weight: {c['fw_bold']}; font-size: {c['font_size_button']}; background: {c['css_transparent']}; }}
    #MsgBody {{ background-color: {c['msg_body_bg']}; border-radius: {c['radius_msg_body']}; }}
    #MsgBodyText {{ color: {c['msg_body_text']}; font-size: {c['font_size_base']}; background: {c['css_transparent']}; }}
    #MsgBtnOk {{
        background-color: {c['msg_btn_ok_bg']}; color: {c['msg_btn_ok_text']};
        border: {c['css_none']}; border-radius: {c['radius_msg_btn']};
        padding: {c['padding_msg_btn']};
        min-height: {c['msg_btn_min_height']}px; min-width: {c['msg_btn_min_width']}px;
        font-weight: {c['fw_bold']};
    }}
    #MsgBtnOk:hover {{ background-color: {c['msg_btn_ok_hover']}; }}

    /* S13 SCROLLBAR */
    QScrollBar:vertical {{ background: {c['scrollbar_track']}; width: {c['scrollbar_width']}px; border: {c['css_none']}; border-radius: {c['scrollbar_handle_radius']}; }}
    QScrollBar::handle:vertical {{ background: {c['scrollbar_handle']}; border-radius: {c['scrollbar_handle_radius']}; min-height: {c['scrollbar_handle_min']}px; margin: {c['scrollbar_margin']}; }}
    QScrollBar::handle:vertical:hover   {{ background: {c['scrollbar_handle_hover']}; }}
    QScrollBar::handle:vertical:pressed {{ background: {c['scrollbar_handle_pressed']}; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
    QScrollBar:horizontal {{ background: {c['scrollbar_track']}; height: {c['scrollbar_width']}px; border: {c['css_none']}; border-radius: {c['scrollbar_handle_radius']}; }}
    QScrollBar::handle:horizontal {{ background: {c['scrollbar_handle']}; border-radius: {c['scrollbar_handle_radius']}; min-width: {c['scrollbar_handle_min']}px; margin: {c['scrollbar_margin']}; }}
    QScrollBar::handle:horizontal:hover {{ background: {c['scrollbar_handle_hover']}; }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}

    /* S14 TOOLTIP */
    QToolTip {{ background-color: {c['surface_alt']}; color: {c['text_primary']}; border: 1px solid {c['border_block']}; border-radius: 4px; padding: 4px 8px; font-size: {c['font_size_small']}; }}

    /* S15 INLINE WARN/ERROR */
    #InlineWarn  {{ background-color: {c['inline_warn_bg']};  border-left: 3px solid {c['inline_warn_border']};  border-radius: 0 4px 4px 0; color: {c['inline_warn_text']};  font-size: {c['font_size_small']}; padding: 6px 10px; }}
    #InlineError {{ background-color: {c['inline_error_bg']}; border-left: 3px solid {c['inline_error_border']}; border-radius: 0 4px 4px 0; color: {c['inline_error_text']}; font-size: {c['font_size_small']}; padding: 6px 10px; }}

    /* S16 VISTA PREVIA */
    #PreviewContainer {{ background-color: {c['preview_bg']}; border: {c['border_width_preview']} solid {c['preview_border']}; border-radius: {c['radius_preview']}; }}

    /* S17 QRADIOBUTTON standalone (asunto del correo) */
    QRadioButton {{ background-color: {c['css_transparent']}; color: {c['text_primary']}; font-size: {c['font_size_base']}; spacing: 6px; }}
    QRadioButton::indicator {{ width: 13px; height: 13px; border-radius: 7px; border: 2px solid {c['radio_dot_border']}; background: {c['surface']}; }}
    QRadioButton::indicator:checked {{ border-color: {c['accent']}; background: {c['accent']}; }}

    /* S18 SEPARADORES */
    QFrame[frameShape="4"] {{ background-color: {c['border_block']}; border: {c['css_none']}; max-height: 1px; }}
    """


def get_palette() -> QPalette:
    """QPalette alineado con Vivaldi Dark 4.x."""
    c = QSSD
    p = QPalette()
    p.setColor(QPalette.Window,          QColor(c['app_bg']))
    p.setColor(QPalette.WindowText,      QColor(c['text_primary']))
    p.setColor(QPalette.Base,            QColor(c['surface']))
    p.setColor(QPalette.AlternateBase,   QColor(c['surface_alt']))
    p.setColor(QPalette.Text,            QColor(c['text_primary']))
    p.setColor(QPalette.Button,          QColor(c['btn_linea_bg']))
    p.setColor(QPalette.ButtonText,      QColor(c['text_primary']))
    p.setColor(QPalette.Highlight,       QColor(c['accent']))
    p.setColor(QPalette.HighlightedText, QColor(c['text_on_accent']))
    p.setColor(QPalette.ToolTipBase,     QColor(c['surface_alt']))
    p.setColor(QPalette.ToolTipText,     QColor(c['text_primary']))
    p.setColor(QPalette.PlaceholderText, QColor(c['text_placeholder']))
    p.setColor(QPalette.Disabled, QPalette.Text,       QColor(c['text_disabled']))
    p.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(c['text_disabled']))
    return p
