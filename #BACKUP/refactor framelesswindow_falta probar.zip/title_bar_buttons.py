# coding: utf-8
"""
framelesswindow/titlebar/title_bar_buttons.py

Title bar button widgets: TitleBarButton, SvgTitleBarButton,
MinimizeButton, MaximizeButton, CloseButton.

Decoupled from any application theme or SVG module.
Button height is injected via the `button_height` constructor parameter
(default: 32). Each app's CustomTitleBar sets this from its own theme.

SVG icons for Min/Max/Close are provided as strings via set_svg_provider()
or fall back to built-in geometric shapes drawn with QPainter.
"""

from enum import Enum

from PySide6.QtCore import QFile, QPointF, QRectF, Qt, Property
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QAbstractButton
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtXml import QDomDocument
from PySide6.QtCore import QByteArray

from .._rc import resource  # noqa: F401  (registers Qt resources)

# ---------------------------------------------------------------------------
# SVG provider — callable injected by each app to supply icon SVG strings.
# Signature: provider(icon_name: str, color: str) -> str
#   icon_name: one of 'minimize', 'maximize', 'restore', 'close'
#   color:     hex color string e.g. '#FFFFFF'
#   returns:   SVG source string
# ---------------------------------------------------------------------------
_svg_provider = None


def set_svg_provider(provider):
    """
    Register an app-level SVG provider for titlebar button icons.

    Call this once at app startup before any TitleBar widgets are created.

    Parameters
    ----------
    provider : callable(icon_name: str, color: str) -> str
        Returns an SVG source string for the given icon name and fill color.
        icon_name is one of: 'minimize', 'maximize', 'restore', 'close'.
    """
    global _svg_provider
    _svg_provider = provider


def _fallback_svg_minimize(color: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
        f'<line x1="3" y1="8" x2="13" y2="8" stroke="{color}" '
        f'stroke-width="1.5" stroke-linecap="round"/></svg>'
    )


def _fallback_svg_maximize(color: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
        f'<rect x="3" y="3" width="10" height="10" fill="none" stroke="{color}" '
        f'stroke-width="1.5" stroke-linejoin="round"/></svg>'
    )


def _fallback_svg_restore(color: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
        f'<rect x="5" y="3" width="8" height="8" fill="none" stroke="{color}" '
        f'stroke-width="1.5" stroke-linejoin="round"/>'
        f'<rect x="3" y="5" width="8" height="8" fill="none" stroke="{color}" '
        f'stroke-width="1.5" stroke-linejoin="round"/></svg>'
    )


def _fallback_svg_close(color: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
        f'<line x1="3" y1="3" x2="13" y2="13" stroke="{color}" '
        f'stroke-width="1.5" stroke-linecap="round"/>'
        f'<line x1="13" y1="3" x2="3" y2="13" stroke="{color}" '
        f'stroke-width="1.5" stroke-linecap="round"/></svg>'
    )


_FALLBACKS = {
    'minimize': _fallback_svg_minimize,
    'maximize': _fallback_svg_maximize,
    'restore':  _fallback_svg_restore,
    'close':    _fallback_svg_close,
}


def _get_icon_svg(icon_name: str, color: str) -> str:
    """Return SVG string from provider or fallback."""
    if _svg_provider is not None:
        try:
            return _svg_provider(icon_name, color)
        except Exception:
            pass
    return _FALLBACKS[icon_name](color)


# ---------------------------------------------------------------------------
# Button classes
# ---------------------------------------------------------------------------

class TitleBarButtonState(Enum):
    """Title bar button state."""
    NORMAL  = 0
    HOVER   = 1
    PRESSED = 2


class TitleBarButton(QAbstractButton):
    """Base title bar button — no icon, paints background only."""

    # Default button height used when no app injects a value.
    DEFAULT_HEIGHT = 32

    def __init__(self, parent=None, button_height: int = DEFAULT_HEIGHT):
        super().__init__(parent=parent)
        self.setCursor(Qt.ArrowCursor)
        self.setFixedSize(46, button_height)
        self._state = TitleBarButtonState.NORMAL

        # icon color
        self._normalColor   = QColor(0, 0, 0)
        self._hoverColor    = QColor(0, 0, 0)
        self._pressedColor  = QColor(0, 0, 0)

        # background color
        self._normalBgColor  = QColor(0, 0, 0, 0)
        self._hoverBgColor   = QColor(0, 0, 0, 26)
        self._pressedBgColor = QColor(0, 0, 0, 51)

    def setState(self, state):
        self._state = state
        self.update()

    def isPressed(self):
        return self._state == TitleBarButtonState.PRESSED

    def getNormalColor(self):          return self._normalColor
    def getHoverColor(self):           return self._hoverColor
    def getPressedColor(self):         return self._pressedColor
    def getNormalBackgroundColor(self):return self._normalBgColor
    def getHoverBackgroundColor(self): return self._hoverBgColor
    def getPressedBackgroundColor(self):return self._pressedBgColor

    def setNormalColor(self, color):
        self._normalColor = QColor(color); self.update()

    def setHoverColor(self, color):
        self._hoverColor = QColor(color); self.update()

    def setPressedColor(self, color):
        self._pressedColor = QColor(color); self.update()

    def setNormalBackgroundColor(self, color):
        self._normalBgColor = QColor(color); self.update()

    def setHoverBackgroundColor(self, color):
        self._hoverBgColor = QColor(color); self.update()

    def setPressedBackgroundColor(self, color):
        self._pressedBgColor = QColor(color); self.update()

    def enterEvent(self, e):
        self.setState(TitleBarButtonState.HOVER)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.setState(TitleBarButtonState.NORMAL)
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        self.setState(TitleBarButtonState.PRESSED)
        super().mousePressEvent(e)

    def _getColors(self):
        if self._state == TitleBarButtonState.NORMAL:
            return self._normalColor, self._normalBgColor
        elif self._state == TitleBarButtonState.HOVER:
            return self._hoverColor, self._hoverBgColor
        return self._pressedColor, self._pressedBgColor

    normalColor           = Property(QColor, getNormalColor,           setNormalColor)
    hoverColor            = Property(QColor, getHoverColor,            setHoverColor)
    pressedColor          = Property(QColor, getPressedColor,          setPressedColor)
    normalBackgroundColor = Property(QColor, getNormalBackgroundColor, setNormalBackgroundColor)
    hoverBackgroundColor  = Property(QColor, getHoverBackgroundColor,  setHoverBackgroundColor)
    pressedBackgroundColor= Property(QColor, getPressedBackgroundColor,setPressedBackgroundColor)


class SvgTitleBarButton(TitleBarButton):
    """Title bar button using an SVG file path as icon."""

    def __init__(self, iconPath, parent=None, button_height: int = TitleBarButton.DEFAULT_HEIGHT):
        super().__init__(parent, button_height)
        self._svgDom = QDomDocument()
        self.setIcon(iconPath)

    def setIcon(self, iconPath):
        f = QFile(iconPath)
        f.open(QFile.ReadOnly)
        self._svgDom.setContent(f.readAll())
        f.close()

    def paintEvent(self, e):
        painter = QPainter(self)
        color, bgColor = self._getColors()
        painter.setBrush(bgColor)
        painter.setPen(Qt.NoPen)
        painter.drawRect(self.rect())

        color_name = color.name()
        pathNodes = self._svgDom.elementsByTagName('path')
        for i in range(pathNodes.length()):
            pathNodes.at(i).toElement().setAttribute('stroke', color_name)

        renderer = QSvgRenderer(self._svgDom.toByteArray())
        bw, bh = self.width(), self.height()
        vb = renderer.viewBox()
        ratio  = (vb.width() / vb.height()) if vb.height() > 0 else 1.5
        icon_h = 20.0
        icon_w = icon_h * ratio
        renderer.render(painter, QRectF((bw - icon_w) / 2, (bh - icon_h) / 2, icon_w, icon_h))


class MinimizeButton(TitleBarButton):
    """Minimize button — icon via SVG provider or geometric fallback."""

    def __init__(self, parent=None, button_height: int = TitleBarButton.DEFAULT_HEIGHT):
        super().__init__(parent, button_height)

    def paintEvent(self, e):
        painter = QPainter(self)
        color, bgColor = self._getColors()
        painter.setBrush(bgColor)
        painter.setPen(Qt.NoPen)
        painter.drawRect(self.rect())

        svg_data = _get_icon_svg('minimize', color.name())
        renderer = QSvgRenderer(QByteArray(svg_data.encode()))
        icon_sz = 14.0
        renderer.render(painter, QRectF(
            (self.width()  - icon_sz) / 2,
            (self.height() - icon_sz) / 2,
            icon_sz, icon_sz,
        ))


class MaximizeButton(TitleBarButton):
    """Maximize / restore button — icon via SVG provider or geometric fallback."""

    def __init__(self, parent=None, button_height: int = TitleBarButton.DEFAULT_HEIGHT):
        super().__init__(parent, button_height)
        self._isMax = False

    def setMaxState(self, isMax):
        if self._isMax == isMax:
            return
        self._isMax = isMax
        self.setState(TitleBarButtonState.NORMAL)

    def paintEvent(self, e):
        painter = QPainter(self)
        color, bgColor = self._getColors()
        painter.setBrush(bgColor)
        painter.setPen(Qt.NoPen)
        painter.drawRect(self.rect())

        icon_name = 'restore' if self._isMax else 'maximize'
        svg_data  = _get_icon_svg(icon_name, color.name())
        renderer  = QSvgRenderer(QByteArray(svg_data.encode()))
        icon_sz = 14.0
        renderer.render(painter, QRectF(
            (self.width()  - icon_sz) / 2,
            (self.height() - icon_sz) / 2,
            icon_sz, icon_sz,
        ))


class CloseButton(TitleBarButton):
    """Close button — red hover background, icon via SVG provider or fallback."""

    def __init__(self, parent=None, button_height: int = TitleBarButton.DEFAULT_HEIGHT):
        super().__init__(parent, button_height)
        self.setHoverColor(Qt.white)
        self.setPressedColor(Qt.white)
        self.setHoverBackgroundColor(QColor(232, 17, 35))
        self.setPressedBackgroundColor(QColor(241, 112, 122))

    def paintEvent(self, e):
        painter = QPainter(self)
        color, bgColor = self._getColors()
        painter.setBrush(bgColor)
        painter.setPen(Qt.NoPen)
        painter.drawRect(self.rect())

        svg_data = _get_icon_svg('close', color.name())
        renderer = QSvgRenderer(QByteArray(svg_data.encode()))
        icon_sz = 18.0
        renderer.render(painter, QRectF(
            (self.width()  - icon_sz) / 2,
            (self.height() - icon_sz) / 2,
            icon_sz, icon_sz,
        ))
