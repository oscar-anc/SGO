# coding: utf-8
"""
framelesswindow — Shared frameless window library for SGO apps.

Forked from qframelesswindow (PySide6). Lives at SGO/framelesswindow/
and is shared across all SGO applications.

Public API
----------
from framelesswindow import FramelessMainWindow, TitleBar
"""

from .titlebar import FramelessMainWindow, TitleBar

__all__ = ['FramelessMainWindow', 'TitleBar']
