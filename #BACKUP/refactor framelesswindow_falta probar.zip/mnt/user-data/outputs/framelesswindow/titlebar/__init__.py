# coding: utf-8
"""
framelesswindow/titlebar/__init__.py

Re-exports TitleBarBase, TitleBar, and FramelessMainWindow from the
underlying qframelesswindow library, and makes the custom button classes
available from this subpackage.

The fork replaces only title_bar_buttons.py; the rest of the library
(drag, resize, native events, maximize) comes from qframelesswindow.
"""

from qframelesswindow import FramelessMainWindow
from qframelesswindow.titlebar import TitleBar, TitleBarBase

from .title_bar_buttons import (
    TitleBarButton,
    SvgTitleBarButton,
    MinimizeButton,
    MaximizeButton,
    CloseButton,
    TitleBarButtonState,
    set_svg_provider,
)

__all__ = [
    'FramelessMainWindow',
    'TitleBar',
    'TitleBarBase',
    'TitleBarButton',
    'SvgTitleBarButton',
    'MinimizeButton',
    'MaximizeButton',
    'CloseButton',
    'TitleBarButtonState',
    'set_svg_provider',
]
