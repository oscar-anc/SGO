# coding: utf-8
import sys

if sys.platform == 'win32':
    from .win32_utils import (
        isGreaterEqualWin8_1, isGreaterEqualWin10, isGreaterEqualWin11,
        isMaximized, isFullScreen, isCompositionEnabled,
        getMonitorInfo, getResizeBorderThickness, findWindow,
        getSystemAccentColor, isSystemBorderAccentEnabled,
        WindowsMoveResize, WindowsScreenCaptureFilter, Taskbar,
    )
elif sys.platform == 'darwin':
    from .mac_utils import (
        MacMoveResize, MacScreenCaptureFilter, getSystemAccentColor,
    )
else:
    from .linux_utils import (
        LinuxMoveResize, LinuxScreenCaptureFilter, getSystemAccentColor,
    )
