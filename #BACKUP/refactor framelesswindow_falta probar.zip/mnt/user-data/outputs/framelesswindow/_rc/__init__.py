# coding: utf-8
from . import resource  # noqa: F401 — registers Qt resources on import
