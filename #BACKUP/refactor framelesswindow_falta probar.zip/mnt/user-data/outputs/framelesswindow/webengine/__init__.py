# coding: utf-8
# WebEngine integration — no changes from upstream qframelesswindow.
# Import from qframelesswindow.webengine if needed.
