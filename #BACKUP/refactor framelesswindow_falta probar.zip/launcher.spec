# -*- mode: python ; coding: utf-8 -*-
# ============================================================
# launcher.spec — SGO Launcher
# ============================================================
# Estructura esperada en producción:
#
#   SGO/
#   ├── launcher.py
#   ├── launcher_apps.json
#   ├── launcher.spec          ← este archivo
#   ├── framelesswindow/       ← módulo compartido
#   ├── imgs/
#   ├── fonts/
#   ├── cartadedespacho.app/
#   └── maildedespacho.app/
#
# Uso:
#   cd SGO/
#   pyinstaller launcher.spec
#
# Genera: dist/SGO.exe  (onefile — portable)
# ============================================================

import os

block_cipher = None

# Directorio raíz = SGO/ (donde vive launcher.spec)
PROJECT_ROOT = os.path.dirname(os.path.abspath(SPEC))


def src(rel):
    """Resuelve una ruta relativa desde SGO/."""
    return os.path.join(PROJECT_ROOT, rel)


# Archivos y carpetas a empaquetar en el ejecutable
datas = [
    (src('launcher_apps.json'), '.'),          # config en raíz del bundle
    (src('imgs'),               'imgs'),       # assets del launcher
    (src('fonts'),              'fonts'),      # fuentes opcionales
    (src('framelesswindow'),    'framelesswindow'),  # módulo compartido
]

# Hidden imports del fork local de framelesswindow.
# Estos submódulos no se detectan automáticamente porque se importan
# condicionalmente (sys.platform) o a través de __init__ dinámico.
_fw_hidden = [
    'framelesswindow',
    'framelesswindow._rc',
    'framelesswindow._rc.resource',
    'framelesswindow.titlebar',
    'framelesswindow.titlebar.title_bar_buttons',
    'framelesswindow.windows',
    'framelesswindow.windows.window_effect',
    'framelesswindow.windows.c_structures',
    'framelesswindow.utils',
    'framelesswindow.utils.win32_utils',
    'framelesswindow.utils.linux_utils',
    'framelesswindow.utils.mac_utils',
    'framelesswindow.linux',
    'framelesswindow.mac',
    'framelesswindow.webengine',
]

a = Analysis(
    [src('launcher.py')],
    pathex=[PROJECT_ROOT],          # SGO/ en el sys.path — encuentra framelesswindow/
    binaries=[],
    datas=datas,
    hiddenimports=_fw_hidden,
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        'tkinter', 'matplotlib', 'numpy', 'scipy', 'pandas',
        'docxtpl', 'docx', 'docx2pdf', 'openpyxl', 'jinja2',
        'IPython', 'PIL', 'Pillow', 'wx', 'PyQt5', 'PyQt6',
        'sphinx', 'pytest', 'setuptools',
    ],
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

_icon_path = src(os.path.join('imgs', 'app_icon_dark.ico'))
_icon = _icon_path if os.path.isfile(_icon_path) else None

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='SGO',
    debug=False,
    strip=False,
    upx=True,
    upx_exclude=['Qt6Core.dll', 'Qt6Gui.dll', 'Qt6Widgets.dll'],
    console=False,
    icon=_icon,
    onefile=True,
)
